package Assignment.com.assignment.suites;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

public class Assignment {

	WebDriver driver;
	
	//elements locator
	String englishLang = "//*[@id='translation-btn']";
	String country = "//*[@id='country-name']";
	String bahrain = "//*[@id='bh-contry-flag']";
	String ksa = "//*[@id='sa-contry-flag']";
	String kuwait = "//*[@id='kw-contry-flag']";
	
	//Bahrain country plan and price locators
	String litePlanBahrain = "//*[@id='name-lite']";
	String liteStarttrial = "//*[@id='lite-selection']";
	String litePlanPrice = "//*[@id='order-tier-price']//b";
	String liteCurrency = "//*[@id='order-total-price' and contains(text(),'BHD/month')]";
	String classicPlanBahrain = "//*[@id='name-classic']";
	String classicStarttrial = "//*[@id='classic-selection']";
	String classicPlanPrice = "//*[@id='order-tier-price']//b";
	String classicCurrency = "//*[@id='order-total-price' and contains(text(),'BHD/month')]";	
	String premiumPlanBahrain = "//*[@id='name-premium']";
	String premiumStarttrial = "//*[@id='premium-selection']";
	String premiumPlanPrice = "//*[@id='order-tier-price']//b";
	String premiumCurrency = "//*[@id='order-total-price' and contains(text(),'BHD/month')]";		
	
	//Kuwait country plan and price locators
	String litePlankuwait = "//*[@id='name-lite']";
	String liteStarttrial1 = "//*[@id='lite-selection']";
	String litePlanPrice1 = "//*[@id='order-tier-price']//b";
	String liteCurrency1 = "//*[@id='order-total-price' and contains(text(),'KWD/month')]";
	String classicPlankuwait = "//*[@id='name-classic']";
	String classicStarttrial1 = "//*[@id='classic-selection']";
	String classicPlanPrice1 = "//*[@id='order-tier-price']//b";
	String classicCurrency1 = "//*[@id='order-total-price' and contains(text(),'KWD/month')]";	
	String premiumPlankuwait = "//*[@id='name-premium']";
	String premiumStarttrial1 = "//*[@id='premium-selection']";
	String premiumPlanPrice1 = "//*[@id='order-tier-price']//b";
	String premiumCurrency1 = "//*[@id='order-total-price' and contains(text(),'KWD/month')]";
	
	//KSA country plan and price locators
	String litePlanksa = "//*[@id='name-lite']";
	String liteStarttrial2 = "//*[@id='lite-selection']";
	String litePlanPrice2 = "//*[@id='order-tier-price']//b";
	String liteCurrency2 = "//*[@id='order-total-price' and contains(text(),'SAR/month')]";
	String classicPlanksa = "//*[@id='name-classic']";
	String classicStarttrial2 = "//*[@id='classic-selection']";
	String classicPlanPrice2 = "//*[@id='order-tier-price']//b";
	String classicCurrency2 = "//*[@id='order-total-price' and contains(text(),'SAR/month')]";	
	String premiumPlanksa = "//*[@id='name-premium']";
	String premiumStarttrial2 = "//*[@id='premium-selection']";
	String premiumPlanPrice2 = "//*[@id='order-tier-price']//b";
	String premiumCurrency2 = "//*[@id='order-total-price' and contains(text(),'SAR/month')]";
	
	
	@BeforeClass
	public void browserSetup() {
		System.setProperty("webdriver.chrome.driver", "C:\\Softwares\\Chromedriver v113\\chromedriver.exe");
		driver = new ChromeDriver();
		System.out.println("Browser started successfully......!!");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@Test
	public void assignment() throws InterruptedException {
		String url = "https://subscribe.stctv.com/";
		System.out.println("Launching the URL : "+url);
		driver.get(url);
		Thread.sleep(5000);
		
		//Clicking on English language element
		driver.findElement(By.xpath(englishLang)).click();
					
		//Clicking on Country element
		driver.findElement(By.xpath(country)).click();
		Thread.sleep(3000);
		
		//Selecting Bahrain country and validating plans and currency
		driver.findElement(By.xpath(bahrain)).click();
		Thread.sleep(3000);		
		System.out.println("........Bahrain country plans......");
		String planText1 = driver.findElement(By.xpath(litePlanBahrain)).getText();
		System.out.println("Plan is : " +planText1);
		Thread.sleep(3000);
		driver.findElement(By.xpath(liteStarttrial)).click();
		Thread.sleep(3000);
		String price1 = driver.findElement(By.xpath(litePlanPrice)).getText();
		System.out.println("Price of Lite plan : " +price1);
		String currency1 = driver.findElement(By.xpath(liteCurrency)).getText();
		System.out.println("Currency of Lite plan : " +currency1);
		driver.navigate().back();
		driver.findElement(By.xpath(country)).click();
		Thread.sleep(3000);		
		//Selecting country
		driver.findElement(By.xpath(bahrain)).click();
		Thread.sleep(3000);
		String planText2 = driver.findElement(By.xpath(classicPlanBahrain)).getText();
		System.out.println("Plan is : " +planText2);
		driver.findElement(By.xpath(classicStarttrial)).click();
		Thread.sleep(3000);
		String price2 = driver.findElement(By.xpath(classicPlanPrice)).getText();
		System.out.println("Price of Classic plan : " +price2);
		String currency2 = driver.findElement(By.xpath(classicCurrency)).getText();
		System.out.println("Currency of Classic plan : " +currency2);
		driver.navigate().back();
		driver.findElement(By.xpath(country)).click();
		Thread.sleep(3000);		
		//Selecting country
		driver.findElement(By.xpath(bahrain)).click();
		Thread.sleep(3000);
		String planText3 = driver.findElement(By.xpath(premiumPlanBahrain)).getText();
		System.out.println("Plan is : " +planText3);
		driver.findElement(By.xpath(premiumStarttrial)).click();
		Thread.sleep(3000);
		String price3 = driver.findElement(By.xpath(premiumPlanPrice)).getText();
		System.out.println("Price of Premium plan : " +price3);
		String currency3 = driver.findElement(By.xpath(premiumCurrency)).getText();
		System.out.println("Currency of Premium plan : " +currency3);
		driver.navigate().back();

		//Selecting Kuwait country and validating plans and currency
		//Clicking on Country element
		driver.findElement(By.xpath(country)).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath(kuwait)).click();
		Thread.sleep(3000);
		System.out.println(".......Kuwait country plans .......");
		String planText4 = driver.findElement(By.xpath(litePlankuwait)).getText();
		System.out.println("Plan is : " +planText4);
		Thread.sleep(3000);
		driver.findElement(By.xpath(liteStarttrial1)).click();
		Thread.sleep(3000);
		String price4 = driver.findElement(By.xpath(litePlanPrice1)).getText();
		System.out.println("Price of Lite plan : " +price4);
		String currency4 = driver.findElement(By.xpath(liteCurrency1)).getText();
		System.out.println("Currency of Lite plan : " +currency4);
		driver.navigate().back();
		driver.findElement(By.xpath(country)).click();
		Thread.sleep(3000);		
		//Selecting country
		driver.findElement(By.xpath(kuwait)).click();
		Thread.sleep(3000);
		String planText5 = driver.findElement(By.xpath(classicPlankuwait)).getText();
		System.out.println("Plan is : " +planText5);
		driver.findElement(By.xpath(classicStarttrial1)).click();
		Thread.sleep(3000);
		String price5 = driver.findElement(By.xpath(classicPlanPrice1)).getText();
		System.out.println("Price of Classic plan : " +price5);
		String currency5 = driver.findElement(By.xpath(classicCurrency1)).getText();
		System.out.println("Currency of Classic plan : " +currency5);
		driver.navigate().back();
		driver.findElement(By.xpath(country)).click();
		Thread.sleep(3000);		
		//Selecting country
		driver.findElement(By.xpath(kuwait)).click();
		Thread.sleep(3000);
		String planText6 = driver.findElement(By.xpath(premiumPlankuwait)).getText();
		System.out.println("Plan is : " +planText6);
		driver.findElement(By.xpath(premiumStarttrial)).click();
		Thread.sleep(3000);
		String price6 = driver.findElement(By.xpath(premiumPlanPrice1)).getText();
		System.out.println("Price of Premium plan : " +price6);
		String currency6 = driver.findElement(By.xpath(premiumCurrency1)).getText();
		System.out.println("Currency of Premium plan : " +currency6);
		driver.navigate().back();
		
		//Selecting KSA country and validating plans and currency
		//Clicking on Country element
		driver.findElement(By.xpath(country)).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath(ksa)).click();
		Thread.sleep(3000);
		System.out.println("........KSA country plans .......");
		String planText9 = driver.findElement(By.xpath(litePlanksa)).getText();
		System.out.println("Plan is : " +planText9);
		Thread.sleep(3000);
		driver.findElement(By.xpath(liteStarttrial2)).click();
		Thread.sleep(3000);
		String price9 = driver.findElement(By.xpath(litePlanPrice2)).getText();
		System.out.println("Price of Lite plan : " +price9);
		String currency9 = driver.findElement(By.xpath(liteCurrency2)).getText();
		System.out.println("Currency of Lite plan : " +currency9);
		driver.navigate().back();
		driver.findElement(By.xpath(englishLang)).click();
		driver.findElement(By.xpath(country)).click();
		Thread.sleep(3000);		
		//Selecting country
		driver.findElement(By.xpath(ksa)).click();
		Thread.sleep(3000);
		String planText7 = driver.findElement(By.xpath(classicPlanksa)).getText();
		System.out.println("Plan is : " +planText7);
		driver.findElement(By.xpath(classicStarttrial2)).click();
		Thread.sleep(3000);
		String price7 = driver.findElement(By.xpath(classicPlanPrice2)).getText();
		System.out.println("Price of Classic plan : " +price7);
		String currency7 = driver.findElement(By.xpath(classicCurrency2)).getText();
		System.out.println("Currency of Classic plan : " +currency7);
		driver.navigate().back();
		driver.findElement(By.xpath(englishLang)).click();
		driver.findElement(By.xpath(country)).click();
		Thread.sleep(3000);		
		//Selecting country
		driver.findElement(By.xpath(ksa)).click();
		Thread.sleep(3000);
		String planText8 = driver.findElement(By.xpath(premiumPlanksa)).getText();
		System.out.println("Plan is : " +planText8);
		driver.findElement(By.xpath(premiumStarttrial2)).click();
		Thread.sleep(3000);
		String price8 = driver.findElement(By.xpath(premiumPlanPrice2)).getText();
		System.out.println("Price of Premium plan : " +price8);
		String currency8 = driver.findElement(By.xpath(premiumCurrency2)).getText();
		System.out.println("Currency of Premium plan : " +currency8);
		driver.navigate().back();
		System.out.println(".........End of the assignment.......");
	}
	
	@AfterClass
	public void broeserQuit() {		
		driver.quit();
		System.out.println("Browser closed successfully....!!");
	}
}
